<template>
  <Layout />
</template>

<script setup>
import Layout from "./components/layout.vue";
</script>
