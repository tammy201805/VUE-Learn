<template>
  <div class="layout">
    <Header />
    <Main />
    <Side />
  </div>
</template>

<script setup>
import Header from "./header.vue";
import Main from "./main.vue";
import Side from "./side.vue";
</script>