<template>
  <div class="main">
    主体
    <LeftNav :NavData="leftNavData" />
    <LeftNav :NavData="rightNavData" />
  </div>
</template>
<script setup>
import { ref } from "vue";
import LeftNav from "../views/Nav.vue";
const leftNavData = ref(["雨天", "晴天"]);
const rightNavData = ref(["赚钱", "亏钱"]);
</script>
