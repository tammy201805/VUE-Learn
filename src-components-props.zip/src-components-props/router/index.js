import { createRouter, createWebHistory } from 'vue-router'

const routes = [
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes:[{
    path: "/:pathMatch(.*)*",
    name: "NotFound",
    component: {}
 }]
})
/* {
  path: "/:pathMatch(.*)*",
  name: "NotFound",
  component: {}
} 
方法来自于:https://pretagteam.com/question/vuerouter-vue-3-createwebhistory-no-match-found-for-location-with-path
*/

export default router
