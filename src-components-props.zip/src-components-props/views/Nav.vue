<template>
  <div class="nav">
    <ul>
      <li v-for="(item, index) in NavData" :key="index">{{ item }}</li>
    </ul>
  </div>
</template>
<script setup>
import { defineProps } from "vue";
const props = defineProps({
  NavData: {
    type: Array,
    default: [],
  },
});
</script>