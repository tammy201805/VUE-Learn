<template>
  <button @click="getSH">获取天气数据</button>
  <p>{{ msg }}</p>
</template>
<script setup>
import api from "../api";
import { ref } from "vue";

const msg = ref("");

function getSH() {
  api
    .getWeatherData({
      key: "578284423109b81c65e95c30f4147ef9",
      area: "上海",
    })
    .then((res) => {
      msg.value = res.data;
      console.log(res.data);
    })
    .catch((error) => {
      console.log(error);
    });
}
</script>