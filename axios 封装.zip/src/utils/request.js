//封装网络请求
import axios from "axios"
import { dialogEmits } from "element-plus";
import qs from "qs"

// 错误信息的响应方法
const errorHandle = (status, other) => {
    switch (status) {
        case 400:
            console.log(status + "（错误请求） 服务器不理解请求的语法")
            break;
        case 404:
            break;
        case 405:
            break;
        default:
            console.log(other)
            break;
    }

}

//创建axios对象
var instance = axios.create({
    timeout: 5000,
})

//全局配置
instance.defaults.baseURL = 'http://api.tianapi.com'
instance.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'

//创建请求拦截和响应拦截操作
instance.interceptors.request.use(config => {
    //配置判断
    if (config.method === "post") {
        config.params = qs.stringify(config.params)
    }
    return config
},
    error => Promise.reject(error)
)

instance.interceptors.response.use(response => response.status === 200 ? Promise.resolve(response) : Promise.reject(response),
    error => {
        const { response } = error //ES6的解构赋值 status data
        if (response) {
            errorHandle(response.status, response.data)
            return Promise.reject(response)
        }dialogEmits.log("请求中断或断网了")

    }


)

export default instance
