//请求方法的统一处理

import base from "./base"
import axios from "../utils/request"

const api = {
    getWeatherData(params) {
        return axios.get(base.baseUrl + base.weatherPath, {
            params: params
        })
    },
    getCovidData(params) {
        return axios.get(base.baseUrl + base.covidPath, {
            params: params
        })
    }
}

export default api