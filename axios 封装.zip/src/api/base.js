//存储全部路径
const base = {
    baseUrl: 'http://api.tianapi.com',
    weatherPath:"/aqi/index",
    covidPath:'/ncov/index'
    
}

export default base